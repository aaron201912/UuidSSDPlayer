cd /
chmod 777 /customer/browser/run.sh &
./customer/browser/run.sh &
cd /customer
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/config/wifi
chmod 777 MyPlayer
./MyPlayer &

